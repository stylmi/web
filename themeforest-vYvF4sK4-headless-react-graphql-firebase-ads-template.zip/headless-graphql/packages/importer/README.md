# Headless Import Export

A script to sync our demo to the stable data.

## Export

To export run the below command

`yarn export`

## Import

To delete existing data and import demo data run the below command

`yarn sync`
