module.exports = {
	type: "service_account",
	project_id: "mateadmin-50901",
	private_key_id: "a1a5ca1f302f6e1fcae7642087b8df337218fd66",
	private_key:
		"-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC/mKwzhbl73+12\nQMgyUryjxOmozN3rBYSWCHdnb/xmcR9gIX3ExTx1p6M1IQKtq1D/zCdJsWy+rFuh\n7UhGxd9vIfXymx1WDuEllbWD5XA1otrUE1dOjYq3vRY+t3Az2Fl1B1ps3YmlTbaN\ndywFE3sL80QFeq3xSviX6BjvldUI06LU6o3/N/P/QkQtJaGQKTZUEo0HOvr3//+Z\nhDHzNv5CQXrCQcbldN2NfisYn0aGV4qRGo1eptmK6scPuu62K74Ph93XGFZ0JpiW\nuyAQmWk3MVWNKZpwLNWLItfHmBvyYN66rXWqbkcPnG4V32kxnU0lTMNnRaNzTAOA\n0V9b79gVAgMBAAECggEABUpAWu3SyL5OjqjMPkN1jOoHb480g2Q0HHZgYZ1AcU2n\nSZ6zG8c8W51Eztc5/TSROHbZENpSv9L/drGYAMg+2pEr+sZYoYMoqUKAcANaPUjh\nVOCx1OvojBku741eDjhng+kvkHjvb359T1uefgdjKtnNI3+XJOXmhj80zQyshKFS\n+s55lKrprNt55o/Txzvn4hIAVMhXFMhc5rrstyAhSGdwZ9l2er4ICKl/eRe867Sa\nuGO919Z1HVQK/1Ed+YmLTS+bjpNXervmB4wMygvFYooo6wQP74w4LFlJ5TjU5X0V\nEMbV17KxF4+0xviWkoEX1mzNVAtJQqLpeTBABPQaQwKBgQD4SSm91//pWOJ7u9H6\nQvIUAfG/tItkrYzQwtD9yrInmoL/YGm/gQ6XJkvByK5UE0FEUayGybb2QMRSHUaR\nCR/7nQTXMzyaZgernSxrXwqOqEwO5JzJHpJQdlr85ocgt863o2J6YSACybkH2XNu\nIJIFQomy9RA+vDKmKaE67XpFCwKBgQDFjJvDMCH+X8GlxpqyZhbKU48qujjEUuAp\n8dE0SutZuj73+zjShaUNFAE6wQVjbQAApIT7iRTR2QSrOQjfvaqozsRIVF0JE/BF\nsAy2hOn5SQAXc5H9BObiqFhWdOBMCWlCNBjh4wOY6QnDFvMnjCzVN6CmXHnTE72+\nYOsSpcJLXwKBgQDz7dVvqX3IQMZKcC2MpSb2Vy6ufG+SmxtEopH3NaQwWpIm2g8q\n0V2HTF2TZlk3Sq+NsnxA9H6nktwOHKsOpRth9VMjJjh9LI6OoV1Zo8dYfqoy25HZ\n2go/uPgNjWLm1w7lxkRjHXb4pjz+JDpO0PsE5ekpA7FRIU7VhwLbRSMiHwKBgAEf\nDzNIbqj2+i5qti4VDkQPvVxMuk3C+qrCSKG3WyajPABEWMo5H/q3BlrDBbjOwZU/\nWdHjsU6PoMsoA7jhZrqWkd6nO+/1QQPkP+45SuqzU2DOsyFwia73raiv+SX1V7ec\nfBesJjUT/Y4x7ydmUErVif/nvnlIP2d5PVxZvISZAoGBAJRWgronS8RPnkYVVX64\nRnYaLKt7IEVyWZQv1B0CY2DyPUnMwEu5l05xWLWyqeTDL0bVOXjv70Wt3nHTu6Ch\nGZNP0OmR/AKWVQsEarrO0BZGE5I/61DF4iLPzj5b9Gsu47FDQ3PEltBQcyCxxe8x\n+sOk7by4t5BaXblqzjN2Wuu9\n-----END PRIVATE KEY-----\n",
	client_email:
		"firebase-adminsdk-nm4g2@mateadmin-50901.iam.gserviceaccount.com",
	client_id: "109131936756116788631",
	auth_uri: "https://accounts.google.com/o/oauth2/auth",
	token_uri: "https://oauth2.googleapis.com/token",
	auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
	client_x509_cert_url:
		"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-nm4g2%40mateadmin-50901.iam.gserviceaccount.com",
};
