import styled from 'styled-components';

export const DropdownField = styled('div')`
  margin-bottom: 2rem;
`;
