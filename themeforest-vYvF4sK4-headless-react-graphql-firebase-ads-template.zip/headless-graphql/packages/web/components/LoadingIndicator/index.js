import React from 'react';
import { Progress } from './LoadingIndicator.style';
export default function LoadingIndicator() {
  return <Progress />;
}
