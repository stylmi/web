import React from 'react';
import SignInForm from '../../SignInForm';

const LoginModal = () => {
  return (
    <div className="NoMargin">
      <SignInForm />
    </div>
  );
};

export default LoginModal;
