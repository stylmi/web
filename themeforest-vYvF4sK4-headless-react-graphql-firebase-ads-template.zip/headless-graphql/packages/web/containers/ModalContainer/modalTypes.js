export const SHARE_MODAL = 'SHARE_MODAL';
