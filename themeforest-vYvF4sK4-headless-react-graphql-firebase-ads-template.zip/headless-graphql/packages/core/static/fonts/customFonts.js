import { createGlobalStyle } from 'styled-components';

export const GlobalStyles = createGlobalStyle`


@import url('https://fonts.googleapis.com/css?family=Lato:400,700');

@import url('https://fonts.googleapis.com/css?family=Poppins:400,700');
@import url('https://unpkg.com/ionicons@4.5.0/dist/css/ionicons.min.css');

`;
